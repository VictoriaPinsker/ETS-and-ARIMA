getwd()
setwd("C:/Users/admin/Desktop/labs")

df <- read.csv("hw5_bike_share_day.csv")
df

library(ggplot2)
install.packages("fpp2")
library(fpp2)





# 1

cntts <- ts(df$cnt, start = 1, frequency = 7)

autoplot(cntts) +
  ggtitle("Daily Bike Share Amount 2011 - 2012") +
  ylab("Bike Share") +
  xlab("Week")

cntts

fit_ses <- ses(cntts, alpha = 0.25, 
               initial = "simple", h = 4)

summary(fit_ses)

MSE_ses <- mean((cntts - fit_ses$fitted)^2)
RMSE_ses <- MSE_ses^0.5
RMSE_ses



fit_ses_opt <- ses(cntts, h = 4)

summary(fit_ses_opt)

MSE_ses_opt <- mean((cntts - fit_ses_opt$fitted)^2)
RMSE_ses_opt <- MSE_ses_opt^0.5
RMSE_ses_opt

RMSE_ses
RMSE_ses_opt


autoplot(cntts, series = "Actual Rental Counts") +
  autolayer(fit_ses$fitted, series = "SES-0.25") +
  autolayer(fit_ses_opt$fitted, series = "SES-Optimal") +
  ggtitle("Bike Rental Counts vs Forecasts") +
  ylab("Amount") +
  xlab("Week") 

# Both models have very similar RMSEs (965.02 vs 964.52).On the plot the SES-0.25 model is
# barely visible because of the overlapping. However, the RMSE for the model with both
# parameters optimized is still slightly lower, so it is a better fit. This makes sense since
# the initial values are optimized along with the smoothing parameters unlike with simple
# method where the initial values are set to values obtained using simple calculations on
# the first few observations.





# 2

fit_holt <- holt(cntts, h = 4)
summary(fit_holt)

autoplot(cntts, series = "Actual Bike Rental Counts") +
  autolayer(fit_holt$fitted, series = "Holt's Forecast") +
  autolayer(fit_ses_opt$fitted, series = "SES-Optimal") +
  ggtitle("Bike Rental Counts vs Forecasts") +
  ylab("Amount") +
  xlab("Year")

tab <- matrix(c('964.5168', '964.7877'), ncol = 1, byrow = FALSE)
colnames(tab) <- c("RMSEs")
rownames(tab) <- c('1: SES', '2: Holts model')
tab

# By comparing the RMSEs we can see that the RMSE from SES is slighly lower, meaning that it
# is a better fit. Holts method allows for forecasting of data with a trend, while SES allows
# for forecasting data with no clear trend or seasonal pattern. The reason why Holts is
# performing worse might be the fact that the trend does not extend to anything past 90 weeks.





# 3

fit_holt_add <- hw(cntts, seasonal = "additive")
summary(fit_holt_add)
fit_holt_mult <- hw(cntts, seasonal = "multiplicative")
summary(fit_holt_mult)
fit_hw_mult_damped <- hw(cntts, damped=TRUE, seasonal="multiplicative")
summary(fit_hw_mult_damped)

tab2 <- matrix(c('964.5168', '964.7877', '953.1229', '957.2871', '944.5366'), ncol = 1, byrow = FALSE)
colnames(tab2) <- c('RMSEs')
rownames(tab2) <- c('SES', 'Holts', 'HW Additive', 'HW Multiplicative', 'HW Damped Multiplicative')
tab2

# According to our RMSEs, Holt-Winters' damped multiplicative model is the best fit. This
# might be attributed to the fact that our trend is strarting to slow down in the middle
# of the year and then go downward, and we are accounting for that with the "damped" parameter.

# It is a little bit surprising that HW additive performs better than HW multiplicative
# though, but it might be due to the fact that the seasonal variation in the data does not
# really increase as the level of the series increases.





# 4

fit_hw_mult_damped_4 <- hw(cntts, damped=TRUE, seasonal="multiplicative", h = 4)
summary(fit_hw_mult_damped_4)

autoplot(cntts, series = "Actual Bike Rental Counts") +
  autolayer(fit_hw_mult_damped_4, series="HW Damped Multiplicative forecasts") +
  ggtitle("Bike Rental Counts vs Forecasts") +
  ylab("Amount") +
  xlab("Week")





# 5

?JohnsonJohnson
range(JohnsonJohnson)

# The range is from 0.44 to 16.20.

length(JohnsonJohnson)

# The length is 84.

fit_aaa <- ets(JohnsonJohnson, model="AAA")
summary(fit_aaa)

coef(fit_aaa)

accuracy(fit_aaa)

fitted(fit_aaa)

autoplot(fit_aaa)

# The data set's periodicity is quarterly. The coefficients are of the AAA ETS model are:
# alpha = 0.07005553, beta = 0.06992075, gamma = 0.85627583.The RMSE is 0.4363976.





# 6

fit_ets2 <- ets(JohnsonJohnson, model = "ANN")
summary(fit_ets2)
#
fit_ets3 <- ets(JohnsonJohnson, model = "AAN")
summary(fit_ets3)
#
fit_ets5 <- ets(JohnsonJohnson, model = "MAA", damped = TRUE)
summary(fit_ets5)
#
fit_ets6 <- ets(JohnsonJohnson, model = "MAM", damped = TRUE)
summary(fit_ets6)


# The optimal model:

fit_ets7 <- ets(JohnsonJohnson)
summary(fit_ets7)


tab3 <- matrix(c('0.436', '1.159', '0.982', '0.462', '0.646', '0.471'), ncol = 1, byrow = FALSE)
colnames(tab3) <- c('RMSEs')
rownames(tab3) <- c('1: ETS-AAA', '2: ETS-ANN', '3: ETS-AAN', '4: ETS-MAA-damped', '5: ETS-MAM-damped', '6: ETS-optimal')
tab3

# ETS-AAA model seems to be a better fit, since it has the lowest RMSE.

# Both ETS-AAA and the "optimal" ets models are close when it comes to their RMSEs. However,
# the optimal model has a much lower AIC (and AICc, but they are almost identical in this
# case since we have a large number of observations) (163.639 vs 250.883). Since AIC
# corrects the RMSE for the number of predictors in the model, thus allowing to account
# for overfitting, the optimal model is preferred.





# 7

# Instead of producing forecasts, the ets function estimates the model parameters and
# returns information about the fitted model. By default it uses the lowest AICc to
# choose the appropriate model rather than the minimum sum of squares. Smoothing parameters
# and initial conditions are optimized using maximum likelihood and a simplex optimizer.





# 8

?debitcards

fit_debt <- ets(debitcards)
summary(fit_debt)

# The model chosen is ETS(M,A,M) - multiplicative Holt-Winters' method with multiplicative
# errors (Error = Multiplicative, Trend = Additive, Season = Multiplicative). The
# parameters associated are alpha = 0.3831, beta = 1e-04, gamma = 5e-04.

fit_debt %>% forecast(h = 24, level = 80) %>%
  autoplot() +
  ylab("Monthly debit card use in Iceland")





# 9

?goog

fit_goog <- ets(goog)
summary(fit_goog)

fit_goog %>% forecast(h = 30) %>%
  autoplot() +
  ylab("Daily closing stock prices of Google Inc with ETS")

# The model chosen is ETS(MNN) - a simple exponential smoothing with multiplicative errors
# (Error = Multiplicative , Trend = None, Season = None). The associated parameter is
# alpha = 0.9999.





# 10

fit_arima <- auto.arima(goog)
summary(fit_arima)
checkresiduals(fit_arima)

fit_arima %>% forecast(h = 30) %>%
  autoplot() +
  ylab("Daily closing stock prices of Google Inc with Arima")

fit_arima$sigma2^0.5

tab4 <- matrix(c('8.729954', '8.728499'), ncol = 1, byrow = FALSE)
colnames(tab4) <- c('RMSEs')
rownames(tab4) <- c('1: ETS', '2: AUTO-ARIMA')
tab4

# The chosen model is ARIMA(0,1,0) with drift. If we compare it to the ETS model, it has a
# slightly lower RMSE, meaning that in this case the auto arima technique worked better,
# however only by a small margin. When we use the checkresiduals function, it is clear that
# there is still some minor autocorrelation out of the threshold limits. The RMSE is 8.72
# (almost identical to the EST(MNN) model's), the AICc=7166.9 (vs 11220.55).